﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProyectoNumero2_JMRM_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            timer1 = new Timer();
            timer1.Tick += new EventHandler(timer1_Tick);
            InitializeComponent();
            timer1.Enabled = true;
        }
        // Se asigna la matriz
        vav[,] matD;
        //  se crea variable para el  contador de E
        int cantEntr = 0;
        int cantC = 0;
        int cantF = 0;
        int cantN = 0;
        private void button1_Click(object sender, EventArgs e)
        {// El OpenFileDialog sirve para abriri la ventana y seleccionar el archivo
            OpenFileDialog txtDo = new OpenFileDialog();
            //Se le asigna que solo debe admitir archivo txt
            txtDo.Filter = "Text File |*.txt"; 
            if (txtDo.ShowDialog() == DialogResult.OK)
            {//Lee el archivo txt
                StreamReader leArch = new StreamReader(txtDo.FileName);
                //Lee la línea
                string sli = leArch.ReadLine();
                string tdLi = "";
                while (sli != null)//Se crea un ciclo que lo repita mientras que la linea del string no sea nula
                {//Crea un solo string con todos los datos del archivo y el / sirve para seprar cada fila
                    tdLi += sli + "/"; 
                    sli = leArch.ReadLine();
                    //Lee la linea
                }
                string[] Filastemp = tdLi.Split('/'); //Por medio del .split y el / permyite saber la cantida de filas por rque cuando termina una linea y lee el / lo toma como una nueva fila y eso ayuda para saber la cantidad de filas. 
                //El ..Length  cuenta la cantida de filas y se le añade -1 por el / que se dio anteriormente para separar las filas  
                int Filas = Filastemp.Length - 1; 
                //  Despues de haber creada el vector con el .split se tomara una fila para obtener las columnas
                string filass = Filastemp[0];
                //Por medio del . split separa los caracteres y crea vectores para las columnas 
                string[] calcularColumnas = filass.Split(' ');
                //Se obtiene la cantidad de columnas de la matriz
                int cantColumnas = calcularColumnas.Length; 
                //Creo la matriz 
                matD = new vav[Filas, cantColumnas];


                for (int y = 0; y < Filas; y++)// despues de haber añadido el archivo se llenara la matriz con los datos
                {//Por medio de cada fila se crean diferentes vectores con los datos de las mismas 
                    string[] dafilas = Filastemp[y].Split(' ');  
                    
                    for (int x = 0; x < cantColumnas; x++)
                    {
                        string dato = dafilas[x].ToUpper();
                        //Se inicia la matriz por eso el new
                        vav DN = new vav();
                         if (dato == "RS")
                        {
                            DN.matT = "RS";
                            DN.cnMa = 3;
                            DN.moV = 1;
                            DN.pos = "libre";
                            matD[y, x] = DN;
                        }
                        else if (dato == "RH")//Robot rapido
                        {
                            DN.matT = "RH";
                            DN.cnMa = 10;
                            DN.moV = 0.33;
                            DN.pos = "libre";
                            matD[y, x] = DN;
                        }
                        else if (dato == "RN")//Robot medio rapido
                        {
                            DN.matT = "RN";
                            DN.cnMa = 5;
                            DN.moV = 0.50;
                            DN.pos = "libre";
                            matD[y, x] = DN;
                            //guarda en la matriz 
                        }
                        else if (dato.Contains("P"))
                        {//Sobre esto caminara el robot 
                            //Se le asigna casilla
                            DN.matT = "P"; 
                            //no contiene material , por ello no alamacena na y por eso epieza em -1
                            DN.matC = -1;
                            matD[y, x] = DN;
                            //guarda en la matriz 
                        }
                        else if (dato.Contains("W"))
                        {
                            DN.matT = "W";
                            DN.matC = -1;
                            matD[y, x] = DN;
                            //guarda en la matriz 
                        }
                        else if (dato.Contains("C"))
                        {
                            var cantidad = dato.Replace("C", ""); //Reemplazo por un valor vacio y gracias a eso se adquiere el numero de almacenamiento

                            if (cantidad == "") 
                            {
                                DN.matT = "C";
                                DN.matC = 10; // Asigna el 10 porque es el valor por defecto si es 0
                                matD[y, x] = DN;
                                //guarda en la matriz 
                                cantC++;
                            }
                            else 
                            {
                                DN.matT = "C";
                                DN.matC = int.Parse(cantidad);
                                matD[y, x] = DN;
                                //guarda en la matriz
                                cantC++;
                            }
                        }
                        else if (dato.Contains("F"))
                        {
                            var cantidad = dato.Replace("F", "");

                            if (cantidad == "")
                            {
                                DN.matT = "F";
                                DN.matC = 10;
                                matD[y, x] = DN;
                                //guarda en la matriz 
                                cantF++;
                            }
                            else
                            {
                                DN.matT = "F";
                                DN.matC = int.Parse(cantidad); //Lo convert0 a entero porque es string
                                matD[y, x] = DN;
                                //guarda en la matriz 
                                cantF++;
                            }
                        }
                        else if (dato.Contains("N"))
                        {
                            var cantidad = dato.Replace("N", ""); //Sustituyo n por  el espacio en blanco 

                            if (cantidad == "")
                            {
                                DN.matT = "N";
                                DN.matC = 10;
                                matD[y, x] = DN;
                                //guarda en la matriz 
                                cantN++;
                            }
                            else
                            {
                                DN.matT = "N";
                                DN.matC = int.Parse(cantidad);
                                matD[y, x] = DN;
                                //guarda en la matriz 
                                cantN++;
                            }
                        }
                        else if (dato.Contains("E")) // El constains sirve para verificar si es E
                        {//Depositar producto o material
                            DN.matT = "E";
                            DN.matC = -1;
                            matD[y, x] = DN;
                            cantEntr++;
                        }

                    }





                }

                string[] posicionDeEntradas = new string[cantEntr]; 
                int i = 0; 

                for (int y = 0; y < Filas; y++)
                {
                    for (int x = 0; x < cantColumnas; x++)
                    {
                        if (matD[y, x].matT == "E")
                        { // Aqui guardo las posiciones de las entradas 
                            posicionDeEntradas[i] = y + "," + x; 
                            i++;
                            // El contador permite que la entrada se vaya acumlando
                        }
                    }
                }
                

            }

            LLenaDG(matD);

        }
        private void LLenaDG(vav[,] matD )
        {
            for(int i=0; i < matD.GetLength(0); i++)
            {//Le doy las madidas al dataGridView1 
                dataGridView1.Height = 300;//tamaño cuadro
                dataGridView1.Width = 350;// tamaño cuadro
                dataGridView1.Columns.Add("C" + i.ToString(), i.ToString());//columna
                dataGridView1.Rows.Add();//fila
                dataGridView1.Rows[i].HeaderCell.Value = i.ToString();
                dataGridView1.Columns[i].Width = 25;
                dataGridView1.Rows[i].Height = 25;
            }
            for (int y = 0; y < matD.GetLength(0); y++)
            {
                for (int x = 0; x < matD.GetLength(1); x++)
            {
                dataGridView1.Rows[y].Cells[x].Value = matD[y, x].matT; // Le asigno los valores para mostrarlos
                }
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label8.Text = DateTime.Now.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            label9.Text= ("Materiales frios " + cantC + "Materiales fragiles " + cantF + "Materiales normales " + cantN);
        }
    }
}
