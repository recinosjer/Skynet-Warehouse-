﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoNumero2_JMRM_
{
    public class vav
    {
        //Aqui se asigna todo material tanto del robot como de la bodega para una mayor facilidad y solo llamarlos
        public string matT;
        public int matC;
        public double moV;
        public int cnMa;
        public string pos; 
       
    }
}
